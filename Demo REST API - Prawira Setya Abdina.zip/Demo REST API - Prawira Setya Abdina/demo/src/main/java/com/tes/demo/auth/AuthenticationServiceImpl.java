package com.tes.demo.auth;

import com.tes.demo.config.JwtService;
import com.tes.demo.dto.request.User.LoginDTO;
import com.tes.demo.dto.request.User.SignUpDTO;
import com.tes.demo.dto.response.User.ResponseUserDTO;
import com.tes.demo.dto.response.User.UserDTO;
import com.tes.demo.entity.UserEntity;
import com.tes.demo.exception.ResultInternalServerErrorException;
import com.tes.demo.exception.ResultNotFoundException;
import com.tes.demo.repository.UserRepository;
import com.tes.demo.role.Role;
import com.tes.demo.util.ConstantUtil;
import com.tes.demo.util.ModelValidateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ModelValidateUtil modelValidateUtil;

    private final JwtService jwtService;

    @Lazy
    @Autowired
    private AuthenticationProvider authenticationProvider;

    @Override
    public ResponseUserDTO createUser(SignUpDTO signUpDTO) {
        // Validasi Emai
        modelValidateUtil.checkUserExist(signUpDTO.getEmail());
        ResponseUserDTO responseUserDTO = new ResponseUserDTO<>();

        try {
            UserEntity user = new UserEntity();
            user.setEmail(signUpDTO.getEmail());
            user.setFirstName(signUpDTO.getFirstName());
            user.setLastName(signUpDTO.getLastName());
            user.setPassword(new BCryptPasswordEncoder().encode(signUpDTO.getPassword()));
            user.setRole(Role.USER);

            user.setCreatedAt(new Date());
            user.setCreatedBy(1);
            user.setUpdatedAt(new Date());
            user.setUpdatedBy(1);
            user.setDeleted(false);
            user.setDeletedAt(new Date());
            user.setDeletedBy(1);

            UserEntity createdUser = userRepository.save(user);
            UserDTO userDTO = new UserDTO();
            userDTO.setUserId(createdUser.getUserId());
            userDTO.setEmail(createdUser.getEmail());
            userDTO.setFirstName(createdUser.getFirstName());
            userDTO.setLastName(createdUser.getLastName());

            responseUserDTO.setCode(ConstantUtil.STATUS_SUCCESS);
            responseUserDTO.setInfo(ConstantUtil.MESSAGE_SUCCESS);
            responseUserDTO.setData(userDTO);
            return responseUserDTO;
        } catch (Exception e){
            throw new ResultInternalServerErrorException("Internal Server Error");
        }
    }

    @Override
    public ResponseUserDTO login(LoginDTO loginDTO) {
        ResponseUserDTO responseUserDTO = new ResponseUserDTO<>();

        UserEntity userExist = modelValidateUtil.checkUser(loginDTO.getEmail());
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        if (!(passwordEncoder.matches(loginDTO.getPassword(), userExist.getPassword())))
            throw new ResultNotFoundException("Password is wrong");

        var user = userRepository.findByEmail(loginDTO.getEmail()).orElseThrow(() -> new IllegalArgumentException("Invalid email"));
        var jwt = jwtService.generateToken(user);

        Map data = new HashMap();
        data.put("token", jwt);
        data.put("userId", user.getUserId());
        data.put("userEmail", user.getEmail());
        data.put("userRole", user.getRole());
        responseUserDTO.setCode(ConstantUtil.STATUS_SUCCESS);
        responseUserDTO.setInfo(ConstantUtil.MESSAGE_SUCCESS);
        responseUserDTO.setData(data);
        return responseUserDTO;
    }
}
