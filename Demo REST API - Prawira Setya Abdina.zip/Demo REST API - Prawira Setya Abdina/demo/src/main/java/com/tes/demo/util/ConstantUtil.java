package com.tes.demo.util;

public class ConstantUtil {

    public static Integer STATUS_EXIST = 409;
    public static Integer TOO_MANY_REQUEST = 429;
    public static Integer STATUS_NOT_FOUND = 404;
    public static Integer STATUS_BAD_REQUEST = 400;
    public static Integer INTERNAL_SERVER_ERROR = 500;
    public static Integer STATUS_SUCCESS = 200;
    public static String API_SECRET_KEY = "756c73805131f935b55cdf6296be8d05350978208d560370e5630bd75b24869e";
    public static final Integer TOKEN_VALIDTY = 1000 * 60 * 60 * 24;
    public static String MESSAGE_SUCCESS = "successfully loaded";
    public static String MESSAGE_NOT_FOUND = "data not found";

}
