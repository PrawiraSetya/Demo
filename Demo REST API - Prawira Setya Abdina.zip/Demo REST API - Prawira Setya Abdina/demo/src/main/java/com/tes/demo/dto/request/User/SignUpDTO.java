package com.tes.demo.dto.request.User;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class SignUpDTO {

    @NotEmpty
    @Size(max = 255, message = "Name has maximum characters")
    private String firstName;

    @NotEmpty
    @Size(max = 255, message = "Name has maximum characters")
    private String lastName;

    @NotEmpty
    @Size(max = 255, message = "Email has maximum characters")
    private String email;

    @NotEmpty
    @Size(max = 255, message = "Password has maximum characters")
    private String password;
}

