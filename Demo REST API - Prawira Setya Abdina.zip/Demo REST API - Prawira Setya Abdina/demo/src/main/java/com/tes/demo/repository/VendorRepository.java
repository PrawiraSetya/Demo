package com.tes.demo.repository;

import com.tes.demo.entity.VendorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorRepository extends JpaRepository<VendorEntity, Long> {

    String query = "FROM vendor " +
            "WHERE (UPPER(item_name) LIKE UPPER(CONCAT('%', CONCAT(?1, '%'))) " +
            "AND (?2 IS NULL OR item_id = ?2)) " +
            "AND deleted = false";

    @Query(value = "SELECT * " + query + " ORDER BY created_at DESC OFFSET ?3 ROWS FETCH NEXT ?4 ROWS ONLY", nativeQuery = true)
    List<VendorEntity> findAllOffsetLimit(String search, Integer itemId, Integer offset, Integer limit);

    @Query(value = "SELECT COUNT(item_name) " + query, nativeQuery = true)
    Integer findAllOffsetLimitCount(String search, Integer itemId);

    @Query(value = "SELECT * FROM vendor WHERE deleted = ?1", nativeQuery = true)
    List<VendorEntity> findAllAndDeleted(Boolean status);

    @Query(value = "SELECT * FROM vendor WHERE item_id = ?1 AND deleted = ?2", nativeQuery = true)
    VendorEntity findByIdAndDeleted(Integer id, Boolean status);

}
