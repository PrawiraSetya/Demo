package com.tes.demo.dto.response.User;

import lombok.Data;

@Data
public class UserDTO {

    private Integer userId;

    private String email;

    private String firstName;

    private String lastName;
}
