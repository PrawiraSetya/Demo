package com.tes.demo.service;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

public interface UserService {

    UserDetailsService userDetailService();

}
