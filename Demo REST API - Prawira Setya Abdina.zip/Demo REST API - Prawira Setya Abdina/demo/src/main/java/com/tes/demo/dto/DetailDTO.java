package com.tes.demo.dto;

import lombok.Data;

@Data
public class DetailDTO {
    private Integer limit;
    private Integer total;
    private Integer totalPage;
}
