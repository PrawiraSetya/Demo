package com.tes.demo.service;

import com.tes.demo.dto.request.Vendor.CreateVendorDTO;
import com.tes.demo.dto.request.Vendor.FilterListVendorDTO;
import com.tes.demo.dto.request.Vendor.UpdateVendorDTO;
import com.tes.demo.dto.response.Vendor.ResponseVendorDTO;
import com.tes.demo.dto.response.Vendor.ResponseVendorDTOS;

public interface VendorService {

    ResponseVendorDTOS findAllItems(FilterListVendorDTO filterListVendorDTO);

    ResponseVendorDTO findItemById(Integer id);

    ResponseVendorDTO insertItem(CreateVendorDTO createVendorDTO);

    ResponseVendorDTO updateItem(UpdateVendorDTO updateVendorDTO, Integer id);

    ResponseVendorDTO deleteItem(Integer id);
}
