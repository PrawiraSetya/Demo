package com.tes.demo.util;

import com.tes.demo.entity.UserEntity;
import com.tes.demo.exception.ResultExistException;
import com.tes.demo.exception.ResultNotFoundException;
import com.tes.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Objects;

@Component
public class ModelValidateUtil {

    @Autowired
    private UserRepository userRepository;

    public UserEntity checkUserExist(String email){
        UserEntity userExist = userRepository.findOneByEmailAndDeleted(email, false);

        if (userExist != null) throw new ResultExistException("Email already registered");

        return userExist;
    }

    public UserEntity checkUser(String email){
        UserEntity userExist = userRepository.findOneByEmailAndDeleted(email, false);

        if (userExist == null) throw new ResultNotFoundException("Email or user not found");

        return userExist;
    }

    public UserEntity checkUserByToken(String token){
        UserEntity userExist = userRepository.findOneByEmailAndDeleted(token, false);

        if (userExist == null) throw new ResultNotFoundException("Token not found or Expired");

        return userExist;
    }

    public String valStrEmpty(String key, Map<String, ?> map){
        Object value = map.get(key);
        return value == null ? "" : value.toString();
    }
}
