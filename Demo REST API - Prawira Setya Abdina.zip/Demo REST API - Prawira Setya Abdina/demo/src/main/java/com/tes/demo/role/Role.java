package com.tes.demo.role;

public enum Role {
    USER,
    ADMIN
}
