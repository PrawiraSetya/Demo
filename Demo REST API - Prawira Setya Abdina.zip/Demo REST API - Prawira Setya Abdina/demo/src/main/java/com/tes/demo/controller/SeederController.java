package com.tes.demo.controller;

import com.tes.demo.dto.response.Vendor.ResponseVendorDTO;
import com.tes.demo.dto.response.Vendor.ResponseVendorSeederDTO;
import com.tes.demo.exception.ResultInternalServerErrorException;
import com.tes.demo.repository.seeder.VendorSeeder;
import com.tes.demo.util.ConstantUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/seed")
public class SeederController {

    @Autowired
    private VendorSeeder vendorSeeder;

    @Autowired
    JdbcTemplate jdbcTemplate;

    /** API for the Seeder **/
    @PostMapping
    public ResponseVendorSeederDTO vendorSeed(){
        try {
            ResponseVendorSeederDTO responseVendorSeederDTO = new ResponseVendorSeederDTO<>();

            jdbcTemplate.update("DELETE FROM vendor");
            jdbcTemplate.execute("SELECT setval(pg_get_serial_sequence('vendor', 'item_id'), 4, false)");

            vendorSeeder.createSeeder();

            responseVendorSeederDTO.setCode(ConstantUtil.STATUS_SUCCESS);
            responseVendorSeederDTO.setInfo("Successfully Seed Vendor Items");

            return responseVendorSeederDTO;
        }catch (Exception e){
            throw new ResultInternalServerErrorException(e.getMessage());
        }
    }
}
