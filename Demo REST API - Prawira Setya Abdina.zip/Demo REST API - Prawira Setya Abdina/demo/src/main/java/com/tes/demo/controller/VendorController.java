package com.tes.demo.controller;

import com.tes.demo.dto.request.Vendor.CreateVendorDTO;
import com.tes.demo.dto.request.Vendor.FilterListVendorDTO;
import com.tes.demo.dto.request.Vendor.UpdateVendorDTO;
import com.tes.demo.dto.response.Vendor.ResponseVendorDTO;
import com.tes.demo.dto.response.Vendor.ResponseVendorDTOS;
import com.tes.demo.service.VendorService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/vendor")
public class VendorController {

    @Autowired
    private VendorService vendorService;

    /** Get All Items **/
    @GetMapping("/item")
    public ResponseEntity findAllItem(FilterListVendorDTO filterListVendorDTO, HttpServletRequest request){
        ResponseVendorDTOS responseVendorDTOS = vendorService.findAllItems(filterListVendorDTO);
        return new ResponseEntity<>(responseVendorDTOS, HttpStatus.OK);
    }

    /** Get Item By Id **/
    @GetMapping("/item/{id}")
    public ResponseEntity findItemById(HttpServletRequest request, @PathVariable Integer id){
        ResponseVendorDTO responseVendorDTO = vendorService.findItemById(id);
        return new ResponseEntity<>(responseVendorDTO, HttpStatus.OK);
    }

    /** Insert Item **/
    @PostMapping("/item")
    public ResponseEntity insertItem(@Valid @RequestBody CreateVendorDTO createVendorDTO,
                                   HttpServletRequest request){
        ResponseVendorDTO responseVendorDTO = vendorService.insertItem(createVendorDTO);
        return new ResponseEntity<>(responseVendorDTO, HttpStatus.CREATED);
    }

    /** Update Item **/
    @PutMapping("/item/{id}")
    public ResponseEntity updateItem(@Valid @RequestBody UpdateVendorDTO updateVendorDTO,
                                     HttpServletRequest request, @PathVariable Integer id){
        ResponseVendorDTO responseVendorDTO = vendorService.updateItem(updateVendorDTO, id);
        return new ResponseEntity<>(responseVendorDTO, HttpStatus.OK);
    }

    /** Delete Item **/
    @DeleteMapping("/item/{id}")
    public ResponseEntity deleteItem(HttpServletRequest request, @PathVariable Integer id){
        ResponseVendorDTO responseVendorDTO = vendorService.deleteItem(id);
        return new ResponseEntity<>(responseVendorDTO, HttpStatus.OK);
    }
}
