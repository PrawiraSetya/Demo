package com.tes.demo.dto.response.User;

import com.tes.demo.dto.DetailDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseUserDTOS<T> {
    private Integer code;
    private String info;
    private DetailDTO detailDTO;
    private T data;
}
