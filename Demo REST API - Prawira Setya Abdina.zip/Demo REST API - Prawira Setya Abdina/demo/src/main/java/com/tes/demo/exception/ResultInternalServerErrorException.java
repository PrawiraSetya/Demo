package com.tes.demo.exception;

public class ResultInternalServerErrorException extends RuntimeException{

    public ResultInternalServerErrorException(String message){
        super(message);
    }
}
