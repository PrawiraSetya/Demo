package com.tes.demo.auth;

import com.tes.demo.dto.request.User.LoginDTO;
import com.tes.demo.dto.request.User.SignUpDTO;
import com.tes.demo.dto.response.User.ResponseUserDTO;

public interface AuthenticationService {

    ResponseUserDTO createUser(SignUpDTO signUpDTO);
    ResponseUserDTO login(LoginDTO loginDTO);

}
