package com.tes.demo.repository;

import com.tes.demo.entity.UserEntity;
import com.tes.demo.role.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<UserEntity, Long> {

    UserEntity findOneByEmailAndDeleted(String email, Boolean status);
    UserEntity findByRole(Role role);
    Optional<UserEntity> findByEmail(String email);
}
