package com.tes.demo.dto.response.User;

import lombok.Data;

@Data
public class ResponseLoginDTO {
    public String token;
    public String email;
}
