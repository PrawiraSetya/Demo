package com.tes.demo.service.impl;

import com.tes.demo.dto.DetailDTO;
import com.tes.demo.dto.request.Vendor.CreateVendorDTO;
import com.tes.demo.dto.request.Vendor.FilterListVendorDTO;
import com.tes.demo.dto.request.Vendor.UpdateVendorDTO;
import com.tes.demo.dto.response.Vendor.ResponseVendorDTO;
import com.tes.demo.dto.response.Vendor.ResponseVendorDTOS;
import com.tes.demo.dto.response.Vendor.VendorDTO;
import com.tes.demo.entity.VendorEntity;
import com.tes.demo.exception.ResultInternalServerErrorException;
import com.tes.demo.exception.ResultNotFoundException;
import com.tes.demo.repository.VendorRepository;
import com.tes.demo.service.VendorService;
import com.tes.demo.util.ConstantUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Component
@Slf4j
public class VendorServiceImpl implements VendorService {

    @Autowired
    private VendorRepository vendorRepository;

    @Override
    public ResponseVendorDTOS findAllItems(FilterListVendorDTO filterListVendorDTO) {
        ResponseVendorDTOS responseVendorDTOS = new ResponseVendorDTOS<>();
        DetailDTO detailDTO = new DetailDTO();
        List<VendorDTO> vendorDTOS = new ArrayList<>();
        List<VendorEntity> items;
        Integer countItems;
        Integer countPage;

        try {
            if (filterListVendorDTO.getLimit() > 0){
                items = vendorRepository.findAllOffsetLimit(filterListVendorDTO.getSearch(),
                        filterListVendorDTO.getItemId(),
                        filterListVendorDTO.getOffset(), filterListVendorDTO.getLimit());
                countItems = vendorRepository.findAllOffsetLimitCount(filterListVendorDTO.getSearch(),
                        filterListVendorDTO.getItemId());
                countPage = (int) Math.ceil((double) countItems / filterListVendorDTO.getLimit());
            }else {
                items = vendorRepository.findAllAndDeleted(false);
                countItems = items.size();
                countPage = 0;
            }
            detailDTO.setLimit(filterListVendorDTO.getLimit());
            detailDTO.setTotal(countItems);
            detailDTO.setTotalPage(countPage);
            for (VendorEntity vendorEntity : items){
                VendorDTO vendorDTO = new VendorDTO();
                vendorDTO.setItemId(vendorEntity.getItemId());
                vendorDTO.setItemName(vendorEntity.getItemName());
                vendorDTO.setItemQty(vendorEntity.getItemQty());
                vendorDTOS.add(vendorDTO);
            }
            responseVendorDTOS.setCode(ConstantUtil.STATUS_SUCCESS);
            responseVendorDTOS.setInfo(ConstantUtil.MESSAGE_SUCCESS);
            responseVendorDTOS.setDetailDTO(detailDTO);
            responseVendorDTOS.setData(vendorDTOS);
            return responseVendorDTOS;
        }catch (Exception e){
            throw new ResultInternalServerErrorException("Internal Server Error");
        }
    }

    @Override
    public ResponseVendorDTO findItemById(Integer id) {
        ResponseVendorDTO responseVendorDTO = new ResponseVendorDTO<>();
        VendorEntity vendorEntity = vendorRepository.findByIdAndDeleted(id,false);
        if (vendorEntity == null ) throw new ResultNotFoundException("Item Not Found");
        try {

            VendorDTO vendorDTO = new VendorDTO();
            vendorDTO.setItemId(vendorEntity.getItemId());
            vendorDTO.setItemName(vendorEntity.getItemName());
            vendorDTO.setItemQty(vendorEntity.getItemQty());

            responseVendorDTO.setCode(ConstantUtil.STATUS_SUCCESS);
            responseVendorDTO.setInfo(ConstantUtil.MESSAGE_SUCCESS);
            responseVendorDTO.setData(vendorDTO);
            return responseVendorDTO;

        } catch (Exception e){
            throw new ResultInternalServerErrorException("Internal server error");
        }
    }

    @Override
    public ResponseVendorDTO insertItem(CreateVendorDTO createVendorDTO) {
        ResponseVendorDTO responseVendorDTO = new ResponseVendorDTO<>();
        try {
            VendorEntity vendorEntity = new VendorEntity();
            vendorEntity.setItemName(createVendorDTO.getItemName());
            vendorEntity.setItemQty(createVendorDTO.getItemQty());

            vendorEntity.setCreatedAt(new Date());
            vendorEntity.setCreatedBy(1);
            vendorEntity.setUpdatedAt(new Date());
            vendorEntity.setUpdatedBy(1);
            vendorEntity.setDeleted(false);
            vendorEntity.setDeletedAt(new Date());
            vendorEntity.setDeletedBy(1);

            VendorEntity createdVendor = vendorRepository.save(vendorEntity);
            VendorDTO vendorDTO = new VendorDTO();

            vendorDTO.setItemId(createdVendor.getItemId());
            vendorDTO.setItemName(createdVendor.getItemName());
            vendorDTO.setItemQty(createdVendor.getItemQty());

            responseVendorDTO.setCode(ConstantUtil.STATUS_SUCCESS);
            responseVendorDTO.setInfo(ConstantUtil.MESSAGE_SUCCESS);
            responseVendorDTO.setData(vendorDTO);
            return responseVendorDTO;
        } catch (Exception e){
            throw new  ResultInternalServerErrorException("Internal Server Error");
        }
    }

    @Override
    public ResponseVendorDTO updateItem(UpdateVendorDTO updateVendorDTO, Integer id) {
        ResponseVendorDTO responseVendorDTO = new ResponseVendorDTO<>();
        VendorEntity vendorEntity = vendorRepository.findByIdAndDeleted(id,false);
        try {
            vendorEntity.setItemId(updateVendorDTO.getItemId());
            vendorEntity.setItemName(updateVendorDTO.getItemName());
            vendorEntity.setItemQty(updateVendorDTO.getItemQty());

            vendorEntity.setUpdatedAt(new Date());
            vendorEntity.setUpdatedBy(1);
            vendorEntity.setDeletedBy(1);

            VendorEntity createdVendor = vendorRepository.save(vendorEntity);
            VendorDTO vendorDTO = new VendorDTO();

            vendorDTO.setItemId(createdVendor.getItemId());
            vendorDTO.setItemName(createdVendor.getItemName());
            vendorDTO.setItemQty(createdVendor.getItemQty());

            responseVendorDTO.setCode(ConstantUtil.STATUS_SUCCESS);
            responseVendorDTO.setInfo(ConstantUtil.MESSAGE_SUCCESS);
            responseVendorDTO.setData(vendorDTO);
            return responseVendorDTO;
        }catch (Exception e){
            throw new ResultInternalServerErrorException("Internal Server Error");
        }
    }

    @Override
    public ResponseVendorDTO deleteItem(Integer id) {
        ResponseVendorDTO responseVendorDTO = new ResponseVendorDTO<>();
        VendorEntity vendorEntity = vendorRepository.findByIdAndDeleted(id, false);
        if (vendorEntity == null) throw new ResultNotFoundException("Items not found");
        try {
            vendorEntity.setDeleted(true);
            VendorEntity createdVendor = vendorRepository.save(vendorEntity);
            VendorDTO vendorDTO = new VendorDTO();

            vendorDTO.setItemId(createdVendor.getItemId());
            vendorDTO.setItemName(createdVendor.getItemName());
            vendorDTO.setItemQty(createdVendor.getItemQty());

            responseVendorDTO.setCode(ConstantUtil.STATUS_SUCCESS);
            responseVendorDTO.setInfo(ConstantUtil.MESSAGE_SUCCESS);
            responseVendorDTO.setData(vendorDTO);
            return responseVendorDTO;
        }catch (Exception e){
            throw new ResultInternalServerErrorException("Internal Server Error");
        }
    }
}
