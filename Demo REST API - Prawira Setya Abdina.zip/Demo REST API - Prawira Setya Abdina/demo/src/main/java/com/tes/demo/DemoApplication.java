package com.tes.demo;

import com.tes.demo.entity.UserEntity;
import com.tes.demo.filter.RateLimitFilter;
import com.tes.demo.repository.UserRepository;
import com.tes.demo.role.Role;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Date;

@Slf4j
@SpringBootApplication(scanBasePackages = "com.tes.demo")
@EnableJpaRepositories(basePackages = "com.tes.demo.repository")
public class DemoApplication implements CommandLineRunner {

	@Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		UserEntity adminAccount = userRepository.findByRole(Role.ADMIN);
		if (adminAccount == null){
			UserEntity userEntity = new UserEntity();
			userEntity.setEmail("admin@mail.com");
			userEntity.setFirstName("admin");
			userEntity.setLastName("admin");
			userEntity.setRole(Role.ADMIN);
			userEntity.setCreatedAt(new Date());
			userEntity.setCreatedBy(null);
			userEntity.setUpdatedAt(null);
			userEntity.setUpdatedBy(null);
			userEntity.setDeleted(false);
			userEntity.setDeletedAt(null);
			userEntity.setDeletedBy(null);
			userEntity.setPassword(new BCryptPasswordEncoder().encode("admin"));
			userRepository.save(userEntity);
		}
	}
}
