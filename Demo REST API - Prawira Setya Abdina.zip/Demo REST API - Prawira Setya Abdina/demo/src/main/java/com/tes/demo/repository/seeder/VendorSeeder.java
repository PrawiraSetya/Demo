package com.tes.demo.repository.seeder;

import org.apache.tomcat.Jar;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class VendorSeeder {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public void createSeeder()
    {
        String sql_vendor = "INSERT INTO vendor (item_id, item_name, item_qty, deleted) VALUES " +
                "('1', 'Fanti', '100', 'false'), " +
                "('2', 'Caco-Calo', '150', 'false'), " +
                "('3', 'Spriti', '80', 'false')";

        jdbcTemplate.update(sql_vendor);
    }
}
